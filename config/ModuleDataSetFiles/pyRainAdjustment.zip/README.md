# rainadjustment toolbox

Main Python tooling to downscale and correct gridded rainfall (or other meteorological) products using rain gauge data.

TODO: expand README once the tool has advanced.
